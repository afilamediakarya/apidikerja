<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TBgDMAYKjVbYqkKT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9KGqKDvIqp3g56sk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OGkrxzc2HBudrRMX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/register-user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MfZGK1yw9XIbNxsR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/change-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EQkKkXiQlVBUXmTT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::26TjCMVTsE8DkNxL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/face_id' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v8f9sonW1aqgAcOs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1xIOu1PgslmxGfGt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/current_user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0YdiHKrCKpBfWTXd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/satuan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xzeF5C2eF192oaf1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/satuan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nzF2OrFKyST7r47K',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/satuan_kerja/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mHyHpUhLGuRAhtXX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/satuan_kerja/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xdpcz0ki6z5vBf78',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pegawai/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r4i4IJaNbkJhBlmV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pegawai/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hTDxR5z26LzhoJUq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pegawai/get-option-agama' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sMNOqNsIZCasUBvh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pegawai/get-option-status-kawin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p19yMzeACwAxL81b',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pegawai/get-option-pendidikan-terakhir' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::htFRbUPY6u3cFSe6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pegawai/get-option-pangkat-golongan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1DN2plvW6VIXuD4J',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pegawai/get-option-status-pegawai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kRmCDrMfOf29n8Dp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/jadwal/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ri5mEuqcsWTrwQIO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/jadwal/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iViFpNtMNw5J88ax',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/profil_daerah/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EUGmFRB6J1zI1HeB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/profil_daerah/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1LwQaS9nU2wIGNdY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/informasi/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iC0RiFaVuMqMV7iz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/informasi/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QPpfvxzGn5H0V8mp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/bidang/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5LEO8t9uQqlVZt6M',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/bidang/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qwa9oi3BxVVJlr7G',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kegiatan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JQSg4mxNacQo4Dtk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kegiatan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6P1SVQzrMLAtXbND',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/skp/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K9iyz5SU2bfVaJQ5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/skp/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TvVLm0Ow4wTKgIa1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/skp/get-option-satuan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::13oKwP39w6eg8Kw6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/skp/get-option-sasaran-kinerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2s64IstIMFPiczVo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/aktivitas/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1i5edaAx9yj50PZb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/aktivitas/list-by-user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Qs2dqICPrdtW8Fi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/aktivitas/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iDe6B8bnC1Afa80S',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/aktivitas/get-option-sasaran-kinerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0MWtptHLg0W6cEq8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/realisasi_skp/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hhVQb3RS24O4sHO8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/realisasi_skp/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kYr99xym6uplpnAh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/atasan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tEzrYQYnPLMgcYmC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/atasan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S14MRiqKYsaVkS0T',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/absen/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f1uKO6qH2jB5mjk0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/absen/get-time-now' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rqWidZ41uQIzepU3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/absen/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zWi5p9MjyiezJYhz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/absen/check-absen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CVSb6CDvxHkbFfp4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/review_skp/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H0ONduOs1oHCS1pA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/review_skp/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T1hnTnIPoO20tc07',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/review_realisasi/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wU2KVPkgtHvPQOkI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/review_realisasi/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZbRXBDlyv0ZtWyCP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perilaku/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ticFwK2ZxxGu70Mf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perilaku/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PegcnIneGZieo9jw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/faq/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wDLFFVfruHCNm8H7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/faq/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t1ZYss414WAKhXPF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kelas_jabatan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DfmrW4QJCun3G7RM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kelas_jabatan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CK8x0F1JX8MSuXko',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kelas_jabatan/get-option-kelas-jabatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y3QRTrFCRerR5tEM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/jabatan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bGgkBYjmUjZHdBbj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/jabatan/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AeWvQrHQ0HwgAmCB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|s(?|atuan(?|/(?|show/([^/]++)(*:44)|update/([^/]++)(*:66)|delete/([^/]++)(*:88))|_kerja/(?|show/([^/]++)(*:119)|update/([^/]++)(*:142)|delete/([^/]++)(*:165)))|kp/(?|show/([^/]++)(*:194)|update/([^/]++)(*:217)|delete/([^/]++)(*:240)))|p(?|e(?|gawai/(?|show/([^/]++)(*:280)|update/([^/]++)(*:303)|delete/([^/]++)(*:326))|rilaku/(?|show/([^/]++)(*:358)|update/([^/]++)(*:381)|delete/([^/]++)(*:404)))|rofil_daerah/(?|show/([^/]++)(*:443)|update/([^/]++)(*:466)|delete/([^/]++)(*:489)))|ja(?|dwal/(?|show/([^/]++)(*:525)|update/([^/]++)(*:548)|delete/([^/]++)(*:571))|batan/(?|show/([^/]++)(*:602)|update/([^/]++)(*:625)|delete/([^/]++)(*:648)|get\\-option\\-jabatan\\-atasan/([^/]++)(*:693)))|informasi/(?|show/([^/]++)(*:729)|update/([^/]++)(*:752)|delete/([^/]++)(*:775))|bidang/(?|show/([^/]++)(*:807)|update/([^/]++)(*:830)|delete/([^/]++)(*:853))|ke(?|giatan/(?|show/([^/]++)(*:890)|update/([^/]++)(*:913)|delete/([^/]++)(*:936))|las_jabatan/(?|show/([^/]++)(*:973)|update/([^/]++)(*:996)|delete/([^/]++)(*:1019)))|a(?|ktivitas/(?|show/([^/]++)(*:1059)|update/([^/]++)(*:1083)|delete/([^/]++)(*:1107))|tasan/(?|show/([^/]++)(*:1139)|update/([^/]++)(*:1163)|delete/([^/]++)(*:1187))|bsen/(?|show/([^/]++)(*:1218)|update/([^/]++)(*:1242)|delete/([^/]++)(*:1266)))|realisasi_skp/(?|show/([^/]++)(*:1307)|update/([^/]++)(*:1331)|delete/([^/]++)(*:1355))|faq/(?|show/([^/]++)(*:1385)|update/([^/]++)(*:1409)|delete/([^/]++)(*:1433))))/?$}sDu',
    ),
    3 => 
    array (
      44 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VLfvj19AwK2wrmaO',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      66 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NywgSktEeO8ClFUL',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      88 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wiVOHFvSKzprfOGP',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      119 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IhYcCVU2DQBOficc',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IeHUFZhGmbPBMJDg',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iHM06WAJlvV8lmtI',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      194 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YkY9ftAydITgTgcZ',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gl7HbcJkkNjhMKL2',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      240 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TG2zwNYQ5pO48CKX',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      280 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ILnuPMclS6PrmhSi',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      303 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m5xqWx0aDcZZdwIU',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PL0znkkUMnw8xVSz',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      358 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nNMcjVzqwax5qLtq',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      381 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mZ3HRHXJ3qbr614K',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      404 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::StWeHyEremyMDMhc',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      443 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rUKSHZtpNIgsHG86',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      466 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2QdXiWiy0c7lS3l1',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      489 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cVeFdC7yYUJ6yXyK',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      525 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wR9nJ4K92pv8XK1C',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      548 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::49vCbRc7WlNBV4DE',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      571 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RSXW1geQm9xYXsxN',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      602 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Pt07QZh7PjUapDwA',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      625 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YbBoQsvd4Lk3FPm5',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      648 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F1uSCMlw2rcQC4F7',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      693 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9CChuup5zPrvqOik',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      729 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7EC6F2BI6l1vzOMm',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      752 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UMUVKCEqEjElG0Qq',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Kn1HZkNs0lBgWyOU',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      807 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dm4OsFHAsYkfcFbW',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      830 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Md6mjliB7N9ZNfV4',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      853 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J4PooDjbhKKoFxA6',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      890 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZeCw80WdmsZNYdX6',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      913 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MnovfjfimEt6Ez8x',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      936 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dKb9oieWFzc5uTen',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RCtYNTTWdqvrRkFn',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      996 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h48OmScJ2nw3PUxW',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1019 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rGdVujybocP36VY5',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1059 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L34OKXsWAsAu93I9',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1083 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2BVgZp31MWmC6dD9',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1107 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vMryioGhjpARcXo7',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1139 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TxZc6bURmMygxtAi',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1163 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e9O4BG2ZCizxMVxZ',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1187 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jv7YPLCySgK9NMmp',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7PbLXfp2LdvgNKYW',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1242 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UFCswwE81AFPb8v3',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1266 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HPgBzHXuOkJuaxlX',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1307 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1U1SSbiYQJR01eEL',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5vlQKoyQAwJdDVXj',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1355 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5v28SEqc1cNJlNTE',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1385 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7i2V2k2d9Mp4B0OB',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1409 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OLGCGFjeOVHJCUry',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1433 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eEcbj4bHJrxeWj5p',
          ),
          1 => 
          array (
            0 => 'params',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::TBgDMAYKjVbYqkKT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::TBgDMAYKjVbYqkKT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9KGqKDvIqp3g56sk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:262:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005494c847000000005dd52c9f";}";s:4:"hash";s:44:"5dMhQndZBdQhRilFL8obPzr7PD1kKpGHzlxRNBbeqQM=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9KGqKDvIqp3g56sk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OGkrxzc2HBudrRMX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::OGkrxzc2HBudrRMX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MfZGK1yw9XIbNxsR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/register-user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@register_user',
        'controller' => 'App\\Http\\Controllers\\AuthController@register_user',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::MfZGK1yw9XIbNxsR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EQkKkXiQlVBUXmTT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/change-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@change_password',
        'controller' => 'App\\Http\\Controllers\\AuthController@change_password',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::EQkKkXiQlVBUXmTT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::26TjCMVTsE8DkNxL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::26TjCMVTsE8DkNxL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v8f9sonW1aqgAcOs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/face_id',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@face_id',
        'controller' => 'App\\Http\\Controllers\\AuthController@face_id',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::v8f9sonW1aqgAcOs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1xIOu1PgslmxGfGt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\dashboardController@get_data',
        'controller' => 'App\\Http\\Controllers\\dashboardController@get_data',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::1xIOu1PgslmxGfGt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0YdiHKrCKpBfWTXd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/current_user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@current_user',
        'controller' => 'App\\Http\\Controllers\\AuthController@current_user',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::0YdiHKrCKpBfWTXd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xzeF5C2eF192oaf1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/satuan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanController@list',
        'controller' => 'App\\Http\\Controllers\\satuanController@list',
        'namespace' => NULL,
        'prefix' => 'api/satuan',
        'where' => 
        array (
        ),
        'as' => 'generated::xzeF5C2eF192oaf1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nzF2OrFKyST7r47K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/satuan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanController@store',
        'controller' => 'App\\Http\\Controllers\\satuanController@store',
        'namespace' => NULL,
        'prefix' => 'api/satuan',
        'where' => 
        array (
        ),
        'as' => 'generated::nzF2OrFKyST7r47K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VLfvj19AwK2wrmaO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/satuan/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanController@show',
        'controller' => 'App\\Http\\Controllers\\satuanController@show',
        'namespace' => NULL,
        'prefix' => 'api/satuan',
        'where' => 
        array (
        ),
        'as' => 'generated::VLfvj19AwK2wrmaO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NywgSktEeO8ClFUL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/satuan/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanController@update',
        'controller' => 'App\\Http\\Controllers\\satuanController@update',
        'namespace' => NULL,
        'prefix' => 'api/satuan',
        'where' => 
        array (
        ),
        'as' => 'generated::NywgSktEeO8ClFUL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wiVOHFvSKzprfOGP' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/satuan/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanController@delete',
        'controller' => 'App\\Http\\Controllers\\satuanController@delete',
        'namespace' => NULL,
        'prefix' => 'api/satuan',
        'where' => 
        array (
        ),
        'as' => 'generated::wiVOHFvSKzprfOGP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mHyHpUhLGuRAhtXX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/satuan_kerja/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanKerjaController@list',
        'controller' => 'App\\Http\\Controllers\\satuanKerjaController@list',
        'namespace' => NULL,
        'prefix' => 'api/satuan_kerja',
        'where' => 
        array (
        ),
        'as' => 'generated::mHyHpUhLGuRAhtXX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Xdpcz0ki6z5vBf78' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/satuan_kerja/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanKerjaController@store',
        'controller' => 'App\\Http\\Controllers\\satuanKerjaController@store',
        'namespace' => NULL,
        'prefix' => 'api/satuan_kerja',
        'where' => 
        array (
        ),
        'as' => 'generated::Xdpcz0ki6z5vBf78',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IhYcCVU2DQBOficc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/satuan_kerja/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanKerjaController@show',
        'controller' => 'App\\Http\\Controllers\\satuanKerjaController@show',
        'namespace' => NULL,
        'prefix' => 'api/satuan_kerja',
        'where' => 
        array (
        ),
        'as' => 'generated::IhYcCVU2DQBOficc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IeHUFZhGmbPBMJDg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/satuan_kerja/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanKerjaController@update',
        'controller' => 'App\\Http\\Controllers\\satuanKerjaController@update',
        'namespace' => NULL,
        'prefix' => 'api/satuan_kerja',
        'where' => 
        array (
        ),
        'as' => 'generated::IeHUFZhGmbPBMJDg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iHM06WAJlvV8lmtI' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/satuan_kerja/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\satuanKerjaController@delete',
        'controller' => 'App\\Http\\Controllers\\satuanKerjaController@delete',
        'namespace' => NULL,
        'prefix' => 'api/satuan_kerja',
        'where' => 
        array (
        ),
        'as' => 'generated::iHM06WAJlvV8lmtI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r4i4IJaNbkJhBlmV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pegawai/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@list',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@list',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::r4i4IJaNbkJhBlmV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hTDxR5z26LzhoJUq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pegawai/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@store',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@store',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::hTDxR5z26LzhoJUq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ILnuPMclS6PrmhSi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pegawai/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@show',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@show',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::ILnuPMclS6PrmhSi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m5xqWx0aDcZZdwIU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pegawai/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@update',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@update',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::m5xqWx0aDcZZdwIU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PL0znkkUMnw8xVSz' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/pegawai/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@delete',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@delete',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::PL0znkkUMnw8xVSz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sMNOqNsIZCasUBvh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pegawai/get-option-agama',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@optionAgama',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@optionAgama',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::sMNOqNsIZCasUBvh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p19yMzeACwAxL81b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pegawai/get-option-status-kawin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@optionStatusKawin',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@optionStatusKawin',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::p19yMzeACwAxL81b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::htFRbUPY6u3cFSe6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pegawai/get-option-pendidikan-terakhir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@pendidikanTerakhir',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@pendidikanTerakhir',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::htFRbUPY6u3cFSe6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1DN2plvW6VIXuD4J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pegawai/get-option-pangkat-golongan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@optionGolongan',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@optionGolongan',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::1DN2plvW6VIXuD4J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kRmCDrMfOf29n8Dp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pegawai/get-option-status-pegawai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\pegawaiController@optionStatusPegawai',
        'controller' => 'App\\Http\\Controllers\\pegawaiController@optionStatusPegawai',
        'namespace' => NULL,
        'prefix' => 'api/pegawai',
        'where' => 
        array (
        ),
        'as' => 'generated::kRmCDrMfOf29n8Dp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ri5mEuqcsWTrwQIO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/jadwal/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jadwalController@list',
        'controller' => 'App\\Http\\Controllers\\jadwalController@list',
        'namespace' => NULL,
        'prefix' => 'api/jadwal',
        'where' => 
        array (
        ),
        'as' => 'generated::Ri5mEuqcsWTrwQIO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iViFpNtMNw5J88ax' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/jadwal/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jadwalController@store',
        'controller' => 'App\\Http\\Controllers\\jadwalController@store',
        'namespace' => NULL,
        'prefix' => 'api/jadwal',
        'where' => 
        array (
        ),
        'as' => 'generated::iViFpNtMNw5J88ax',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wR9nJ4K92pv8XK1C' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/jadwal/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jadwalController@show',
        'controller' => 'App\\Http\\Controllers\\jadwalController@show',
        'namespace' => NULL,
        'prefix' => 'api/jadwal',
        'where' => 
        array (
        ),
        'as' => 'generated::wR9nJ4K92pv8XK1C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::49vCbRc7WlNBV4DE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/jadwal/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jadwalController@update',
        'controller' => 'App\\Http\\Controllers\\jadwalController@update',
        'namespace' => NULL,
        'prefix' => 'api/jadwal',
        'where' => 
        array (
        ),
        'as' => 'generated::49vCbRc7WlNBV4DE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RSXW1geQm9xYXsxN' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/jadwal/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jadwalController@delete',
        'controller' => 'App\\Http\\Controllers\\jadwalController@delete',
        'namespace' => NULL,
        'prefix' => 'api/jadwal',
        'where' => 
        array (
        ),
        'as' => 'generated::RSXW1geQm9xYXsxN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EUGmFRB6J1zI1HeB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/profil_daerah/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\profilDaerahController@list',
        'controller' => 'App\\Http\\Controllers\\profilDaerahController@list',
        'namespace' => NULL,
        'prefix' => 'api/profil_daerah',
        'where' => 
        array (
        ),
        'as' => 'generated::EUGmFRB6J1zI1HeB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1LwQaS9nU2wIGNdY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/profil_daerah/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\profilDaerahController@store',
        'controller' => 'App\\Http\\Controllers\\profilDaerahController@store',
        'namespace' => NULL,
        'prefix' => 'api/profil_daerah',
        'where' => 
        array (
        ),
        'as' => 'generated::1LwQaS9nU2wIGNdY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rUKSHZtpNIgsHG86' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/profil_daerah/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\profilDaerahController@show',
        'controller' => 'App\\Http\\Controllers\\profilDaerahController@show',
        'namespace' => NULL,
        'prefix' => 'api/profil_daerah',
        'where' => 
        array (
        ),
        'as' => 'generated::rUKSHZtpNIgsHG86',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2QdXiWiy0c7lS3l1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/profil_daerah/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\profilDaerahController@update',
        'controller' => 'App\\Http\\Controllers\\profilDaerahController@update',
        'namespace' => NULL,
        'prefix' => 'api/profil_daerah',
        'where' => 
        array (
        ),
        'as' => 'generated::2QdXiWiy0c7lS3l1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cVeFdC7yYUJ6yXyK' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/profil_daerah/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\profilDaerahController@delete',
        'controller' => 'App\\Http\\Controllers\\profilDaerahController@delete',
        'namespace' => NULL,
        'prefix' => 'api/profil_daerah',
        'where' => 
        array (
        ),
        'as' => 'generated::cVeFdC7yYUJ6yXyK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iC0RiFaVuMqMV7iz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/informasi/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\informasiController@list',
        'controller' => 'App\\Http\\Controllers\\informasiController@list',
        'namespace' => NULL,
        'prefix' => 'api/informasi',
        'where' => 
        array (
        ),
        'as' => 'generated::iC0RiFaVuMqMV7iz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QPpfvxzGn5H0V8mp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/informasi/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\informasiController@store',
        'controller' => 'App\\Http\\Controllers\\informasiController@store',
        'namespace' => NULL,
        'prefix' => 'api/informasi',
        'where' => 
        array (
        ),
        'as' => 'generated::QPpfvxzGn5H0V8mp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7EC6F2BI6l1vzOMm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/informasi/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\informasiController@show',
        'controller' => 'App\\Http\\Controllers\\informasiController@show',
        'namespace' => NULL,
        'prefix' => 'api/informasi',
        'where' => 
        array (
        ),
        'as' => 'generated::7EC6F2BI6l1vzOMm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UMUVKCEqEjElG0Qq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/informasi/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\informasiController@update',
        'controller' => 'App\\Http\\Controllers\\informasiController@update',
        'namespace' => NULL,
        'prefix' => 'api/informasi',
        'where' => 
        array (
        ),
        'as' => 'generated::UMUVKCEqEjElG0Qq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Kn1HZkNs0lBgWyOU' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/informasi/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\informasiController@delete',
        'controller' => 'App\\Http\\Controllers\\informasiController@delete',
        'namespace' => NULL,
        'prefix' => 'api/informasi',
        'where' => 
        array (
        ),
        'as' => 'generated::Kn1HZkNs0lBgWyOU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5LEO8t9uQqlVZt6M' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/bidang/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\bidangController@list',
        'controller' => 'App\\Http\\Controllers\\bidangController@list',
        'namespace' => NULL,
        'prefix' => 'api/bidang',
        'where' => 
        array (
        ),
        'as' => 'generated::5LEO8t9uQqlVZt6M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qwa9oi3BxVVJlr7G' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/bidang/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\bidangController@store',
        'controller' => 'App\\Http\\Controllers\\bidangController@store',
        'namespace' => NULL,
        'prefix' => 'api/bidang',
        'where' => 
        array (
        ),
        'as' => 'generated::qwa9oi3BxVVJlr7G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dm4OsFHAsYkfcFbW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/bidang/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\bidangController@show',
        'controller' => 'App\\Http\\Controllers\\bidangController@show',
        'namespace' => NULL,
        'prefix' => 'api/bidang',
        'where' => 
        array (
        ),
        'as' => 'generated::dm4OsFHAsYkfcFbW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Md6mjliB7N9ZNfV4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/bidang/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\bidangController@update',
        'controller' => 'App\\Http\\Controllers\\bidangController@update',
        'namespace' => NULL,
        'prefix' => 'api/bidang',
        'where' => 
        array (
        ),
        'as' => 'generated::Md6mjliB7N9ZNfV4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J4PooDjbhKKoFxA6' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/bidang/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\bidangController@delete',
        'controller' => 'App\\Http\\Controllers\\bidangController@delete',
        'namespace' => NULL,
        'prefix' => 'api/bidang',
        'where' => 
        array (
        ),
        'as' => 'generated::J4PooDjbhKKoFxA6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JQSg4mxNacQo4Dtk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kegiatan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kegiatanController@list',
        'controller' => 'App\\Http\\Controllers\\kegiatanController@list',
        'namespace' => NULL,
        'prefix' => 'api/kegiatan',
        'where' => 
        array (
        ),
        'as' => 'generated::JQSg4mxNacQo4Dtk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6P1SVQzrMLAtXbND' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kegiatan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kegiatanController@store',
        'controller' => 'App\\Http\\Controllers\\kegiatanController@store',
        'namespace' => NULL,
        'prefix' => 'api/kegiatan',
        'where' => 
        array (
        ),
        'as' => 'generated::6P1SVQzrMLAtXbND',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZeCw80WdmsZNYdX6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kegiatan/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kegiatanController@show',
        'controller' => 'App\\Http\\Controllers\\kegiatanController@show',
        'namespace' => NULL,
        'prefix' => 'api/kegiatan',
        'where' => 
        array (
        ),
        'as' => 'generated::ZeCw80WdmsZNYdX6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MnovfjfimEt6Ez8x' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kegiatan/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kegiatanController@update',
        'controller' => 'App\\Http\\Controllers\\kegiatanController@update',
        'namespace' => NULL,
        'prefix' => 'api/kegiatan',
        'where' => 
        array (
        ),
        'as' => 'generated::MnovfjfimEt6Ez8x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dKb9oieWFzc5uTen' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/kegiatan/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kegiatanController@delete',
        'controller' => 'App\\Http\\Controllers\\kegiatanController@delete',
        'namespace' => NULL,
        'prefix' => 'api/kegiatan',
        'where' => 
        array (
        ),
        'as' => 'generated::dKb9oieWFzc5uTen',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K9iyz5SU2bfVaJQ5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/skp/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\skpController@list',
        'controller' => 'App\\Http\\Controllers\\skpController@list',
        'namespace' => NULL,
        'prefix' => 'api/skp',
        'where' => 
        array (
        ),
        'as' => 'generated::K9iyz5SU2bfVaJQ5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TvVLm0Ow4wTKgIa1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/skp/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\skpController@store',
        'controller' => 'App\\Http\\Controllers\\skpController@store',
        'namespace' => NULL,
        'prefix' => 'api/skp',
        'where' => 
        array (
        ),
        'as' => 'generated::TvVLm0Ow4wTKgIa1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YkY9ftAydITgTgcZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/skp/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\skpController@show',
        'controller' => 'App\\Http\\Controllers\\skpController@show',
        'namespace' => NULL,
        'prefix' => 'api/skp',
        'where' => 
        array (
        ),
        'as' => 'generated::YkY9ftAydITgTgcZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gl7HbcJkkNjhMKL2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/skp/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\skpController@update',
        'controller' => 'App\\Http\\Controllers\\skpController@update',
        'namespace' => NULL,
        'prefix' => 'api/skp',
        'where' => 
        array (
        ),
        'as' => 'generated::gl7HbcJkkNjhMKL2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TG2zwNYQ5pO48CKX' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/skp/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\skpController@delete',
        'controller' => 'App\\Http\\Controllers\\skpController@delete',
        'namespace' => NULL,
        'prefix' => 'api/skp',
        'where' => 
        array (
        ),
        'as' => 'generated::TG2zwNYQ5pO48CKX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::13oKwP39w6eg8Kw6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/skp/get-option-satuan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\skpController@satuan',
        'controller' => 'App\\Http\\Controllers\\skpController@satuan',
        'namespace' => NULL,
        'prefix' => 'api/skp',
        'where' => 
        array (
        ),
        'as' => 'generated::13oKwP39w6eg8Kw6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2s64IstIMFPiczVo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/skp/get-option-sasaran-kinerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\skpController@optionSkp',
        'controller' => 'App\\Http\\Controllers\\skpController@optionSkp',
        'namespace' => NULL,
        'prefix' => 'api/skp',
        'where' => 
        array (
        ),
        'as' => 'generated::2s64IstIMFPiczVo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1i5edaAx9yj50PZb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/aktivitas/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\aktivitasController@list',
        'controller' => 'App\\Http\\Controllers\\aktivitasController@list',
        'namespace' => NULL,
        'prefix' => 'api/aktivitas',
        'where' => 
        array (
        ),
        'as' => 'generated::1i5edaAx9yj50PZb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2Qs2dqICPrdtW8Fi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/aktivitas/list-by-user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\aktivitasController@listByUser',
        'controller' => 'App\\Http\\Controllers\\aktivitasController@listByUser',
        'namespace' => NULL,
        'prefix' => 'api/aktivitas',
        'where' => 
        array (
        ),
        'as' => 'generated::2Qs2dqICPrdtW8Fi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iDe6B8bnC1Afa80S' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/aktivitas/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\aktivitasController@store',
        'controller' => 'App\\Http\\Controllers\\aktivitasController@store',
        'namespace' => NULL,
        'prefix' => 'api/aktivitas',
        'where' => 
        array (
        ),
        'as' => 'generated::iDe6B8bnC1Afa80S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L34OKXsWAsAu93I9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/aktivitas/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\aktivitasController@show',
        'controller' => 'App\\Http\\Controllers\\aktivitasController@show',
        'namespace' => NULL,
        'prefix' => 'api/aktivitas',
        'where' => 
        array (
        ),
        'as' => 'generated::L34OKXsWAsAu93I9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2BVgZp31MWmC6dD9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/aktivitas/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\aktivitasController@update',
        'controller' => 'App\\Http\\Controllers\\aktivitasController@update',
        'namespace' => NULL,
        'prefix' => 'api/aktivitas',
        'where' => 
        array (
        ),
        'as' => 'generated::2BVgZp31MWmC6dD9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vMryioGhjpARcXo7' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/aktivitas/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\aktivitasController@delete',
        'controller' => 'App\\Http\\Controllers\\aktivitasController@delete',
        'namespace' => NULL,
        'prefix' => 'api/aktivitas',
        'where' => 
        array (
        ),
        'as' => 'generated::vMryioGhjpARcXo7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0MWtptHLg0W6cEq8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/aktivitas/get-option-sasaran-kinerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\aktivitasController@optionSkp',
        'controller' => 'App\\Http\\Controllers\\aktivitasController@optionSkp',
        'namespace' => NULL,
        'prefix' => 'api/aktivitas',
        'where' => 
        array (
        ),
        'as' => 'generated::0MWtptHLg0W6cEq8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hhVQb3RS24O4sHO8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/realisasi_skp/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\realisasiController@list',
        'controller' => 'App\\Http\\Controllers\\realisasiController@list',
        'namespace' => NULL,
        'prefix' => 'api/realisasi_skp',
        'where' => 
        array (
        ),
        'as' => 'generated::hhVQb3RS24O4sHO8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kYr99xym6uplpnAh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/realisasi_skp/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\realisasiController@store',
        'controller' => 'App\\Http\\Controllers\\realisasiController@store',
        'namespace' => NULL,
        'prefix' => 'api/realisasi_skp',
        'where' => 
        array (
        ),
        'as' => 'generated::kYr99xym6uplpnAh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1U1SSbiYQJR01eEL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/realisasi_skp/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\realisasiController@show',
        'controller' => 'App\\Http\\Controllers\\realisasiController@show',
        'namespace' => NULL,
        'prefix' => 'api/realisasi_skp',
        'where' => 
        array (
        ),
        'as' => 'generated::1U1SSbiYQJR01eEL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5vlQKoyQAwJdDVXj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/realisasi_skp/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\realisasiController@update',
        'controller' => 'App\\Http\\Controllers\\realisasiController@update',
        'namespace' => NULL,
        'prefix' => 'api/realisasi_skp',
        'where' => 
        array (
        ),
        'as' => 'generated::5vlQKoyQAwJdDVXj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5v28SEqc1cNJlNTE' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/realisasi_skp/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\realisasiController@delete',
        'controller' => 'App\\Http\\Controllers\\realisasiController@delete',
        'namespace' => NULL,
        'prefix' => 'api/realisasi_skp',
        'where' => 
        array (
        ),
        'as' => 'generated::5v28SEqc1cNJlNTE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tEzrYQYnPLMgcYmC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/atasan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\atasanController@list',
        'controller' => 'App\\Http\\Controllers\\atasanController@list',
        'namespace' => NULL,
        'prefix' => 'api/atasan',
        'where' => 
        array (
        ),
        'as' => 'generated::tEzrYQYnPLMgcYmC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S14MRiqKYsaVkS0T' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/atasan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\atasanController@store',
        'controller' => 'App\\Http\\Controllers\\atasanController@store',
        'namespace' => NULL,
        'prefix' => 'api/atasan',
        'where' => 
        array (
        ),
        'as' => 'generated::S14MRiqKYsaVkS0T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TxZc6bURmMygxtAi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/atasan/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\atasanController@show',
        'controller' => 'App\\Http\\Controllers\\atasanController@show',
        'namespace' => NULL,
        'prefix' => 'api/atasan',
        'where' => 
        array (
        ),
        'as' => 'generated::TxZc6bURmMygxtAi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e9O4BG2ZCizxMVxZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/atasan/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\atasanController@update',
        'controller' => 'App\\Http\\Controllers\\atasanController@update',
        'namespace' => NULL,
        'prefix' => 'api/atasan',
        'where' => 
        array (
        ),
        'as' => 'generated::e9O4BG2ZCizxMVxZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jv7YPLCySgK9NMmp' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/atasan/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\atasanController@delete',
        'controller' => 'App\\Http\\Controllers\\atasanController@delete',
        'namespace' => NULL,
        'prefix' => 'api/atasan',
        'where' => 
        array (
        ),
        'as' => 'generated::Jv7YPLCySgK9NMmp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f1uKO6qH2jB5mjk0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/absen/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\absenController@list',
        'controller' => 'App\\Http\\Controllers\\absenController@list',
        'namespace' => NULL,
        'prefix' => 'api/absen',
        'where' => 
        array (
        ),
        'as' => 'generated::f1uKO6qH2jB5mjk0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rqWidZ41uQIzepU3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/absen/get-time-now',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\absenController@getTime',
        'controller' => 'App\\Http\\Controllers\\absenController@getTime',
        'namespace' => NULL,
        'prefix' => 'api/absen',
        'where' => 
        array (
        ),
        'as' => 'generated::rqWidZ41uQIzepU3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zWi5p9MjyiezJYhz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/absen/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\absenController@store',
        'controller' => 'App\\Http\\Controllers\\absenController@store',
        'namespace' => NULL,
        'prefix' => 'api/absen',
        'where' => 
        array (
        ),
        'as' => 'generated::zWi5p9MjyiezJYhz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7PbLXfp2LdvgNKYW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/absen/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\absenController@show',
        'controller' => 'App\\Http\\Controllers\\absenController@show',
        'namespace' => NULL,
        'prefix' => 'api/absen',
        'where' => 
        array (
        ),
        'as' => 'generated::7PbLXfp2LdvgNKYW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UFCswwE81AFPb8v3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/absen/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\absenController@update',
        'controller' => 'App\\Http\\Controllers\\absenController@update',
        'namespace' => NULL,
        'prefix' => 'api/absen',
        'where' => 
        array (
        ),
        'as' => 'generated::UFCswwE81AFPb8v3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HPgBzHXuOkJuaxlX' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/absen/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\absenController@delete',
        'controller' => 'App\\Http\\Controllers\\absenController@delete',
        'namespace' => NULL,
        'prefix' => 'api/absen',
        'where' => 
        array (
        ),
        'as' => 'generated::HPgBzHXuOkJuaxlX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CVSb6CDvxHkbFfp4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/absen/check-absen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\absenController@checkAbsen',
        'controller' => 'App\\Http\\Controllers\\absenController@checkAbsen',
        'namespace' => NULL,
        'prefix' => 'api/absen',
        'where' => 
        array (
        ),
        'as' => 'generated::CVSb6CDvxHkbFfp4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H0ONduOs1oHCS1pA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/review_skp/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\reviewController@list',
        'controller' => 'App\\Http\\Controllers\\reviewController@list',
        'namespace' => NULL,
        'prefix' => 'api/review_skp',
        'where' => 
        array (
        ),
        'as' => 'generated::H0ONduOs1oHCS1pA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T1hnTnIPoO20tc07' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/review_skp/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\reviewController@store',
        'controller' => 'App\\Http\\Controllers\\reviewController@store',
        'namespace' => NULL,
        'prefix' => 'api/review_skp',
        'where' => 
        array (
        ),
        'as' => 'generated::T1hnTnIPoO20tc07',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wU2KVPkgtHvPQOkI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/review_realisasi/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\reviewRealisasiSkpController@list',
        'controller' => 'App\\Http\\Controllers\\reviewRealisasiSkpController@list',
        'namespace' => NULL,
        'prefix' => 'api/review_realisasi',
        'where' => 
        array (
        ),
        'as' => 'generated::wU2KVPkgtHvPQOkI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZbRXBDlyv0ZtWyCP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/review_realisasi/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\reviewRealisasiSkpController@store',
        'controller' => 'App\\Http\\Controllers\\reviewRealisasiSkpController@store',
        'namespace' => NULL,
        'prefix' => 'api/review_realisasi',
        'where' => 
        array (
        ),
        'as' => 'generated::ZbRXBDlyv0ZtWyCP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ticFwK2ZxxGu70Mf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/perilaku/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\perilakuController@list',
        'controller' => 'App\\Http\\Controllers\\perilakuController@list',
        'namespace' => NULL,
        'prefix' => 'api/perilaku',
        'where' => 
        array (
        ),
        'as' => 'generated::ticFwK2ZxxGu70Mf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PegcnIneGZieo9jw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/perilaku/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\perilakuController@store',
        'controller' => 'App\\Http\\Controllers\\perilakuController@store',
        'namespace' => NULL,
        'prefix' => 'api/perilaku',
        'where' => 
        array (
        ),
        'as' => 'generated::PegcnIneGZieo9jw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nNMcjVzqwax5qLtq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/perilaku/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\perilakuController@show',
        'controller' => 'App\\Http\\Controllers\\perilakuController@show',
        'namespace' => NULL,
        'prefix' => 'api/perilaku',
        'where' => 
        array (
        ),
        'as' => 'generated::nNMcjVzqwax5qLtq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mZ3HRHXJ3qbr614K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/perilaku/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\perilakuController@update',
        'controller' => 'App\\Http\\Controllers\\perilakuController@update',
        'namespace' => NULL,
        'prefix' => 'api/perilaku',
        'where' => 
        array (
        ),
        'as' => 'generated::mZ3HRHXJ3qbr614K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::StWeHyEremyMDMhc' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/perilaku/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\perilakuController@delete',
        'controller' => 'App\\Http\\Controllers\\perilakuController@delete',
        'namespace' => NULL,
        'prefix' => 'api/perilaku',
        'where' => 
        array (
        ),
        'as' => 'generated::StWeHyEremyMDMhc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wDLFFVfruHCNm8H7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/faq/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\faqController@list',
        'controller' => 'App\\Http\\Controllers\\faqController@list',
        'namespace' => NULL,
        'prefix' => 'api/faq',
        'where' => 
        array (
        ),
        'as' => 'generated::wDLFFVfruHCNm8H7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t1ZYss414WAKhXPF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/faq/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\faqController@store',
        'controller' => 'App\\Http\\Controllers\\faqController@store',
        'namespace' => NULL,
        'prefix' => 'api/faq',
        'where' => 
        array (
        ),
        'as' => 'generated::t1ZYss414WAKhXPF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7i2V2k2d9Mp4B0OB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/faq/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\faqController@show',
        'controller' => 'App\\Http\\Controllers\\faqController@show',
        'namespace' => NULL,
        'prefix' => 'api/faq',
        'where' => 
        array (
        ),
        'as' => 'generated::7i2V2k2d9Mp4B0OB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OLGCGFjeOVHJCUry' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/faq/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\faqController@update',
        'controller' => 'App\\Http\\Controllers\\faqController@update',
        'namespace' => NULL,
        'prefix' => 'api/faq',
        'where' => 
        array (
        ),
        'as' => 'generated::OLGCGFjeOVHJCUry',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eEcbj4bHJrxeWj5p' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/faq/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\faqController@delete',
        'controller' => 'App\\Http\\Controllers\\faqController@delete',
        'namespace' => NULL,
        'prefix' => 'api/faq',
        'where' => 
        array (
        ),
        'as' => 'generated::eEcbj4bHJrxeWj5p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DfmrW4QJCun3G7RM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kelas_jabatan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kelasJabatanController@list',
        'controller' => 'App\\Http\\Controllers\\kelasJabatanController@list',
        'namespace' => NULL,
        'prefix' => 'api/kelas_jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::DfmrW4QJCun3G7RM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CK8x0F1JX8MSuXko' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kelas_jabatan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kelasJabatanController@store',
        'controller' => 'App\\Http\\Controllers\\kelasJabatanController@store',
        'namespace' => NULL,
        'prefix' => 'api/kelas_jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::CK8x0F1JX8MSuXko',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RCtYNTTWdqvrRkFn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kelas_jabatan/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kelasJabatanController@show',
        'controller' => 'App\\Http\\Controllers\\kelasJabatanController@show',
        'namespace' => NULL,
        'prefix' => 'api/kelas_jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::RCtYNTTWdqvrRkFn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h48OmScJ2nw3PUxW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/kelas_jabatan/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kelasJabatanController@update',
        'controller' => 'App\\Http\\Controllers\\kelasJabatanController@update',
        'namespace' => NULL,
        'prefix' => 'api/kelas_jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::h48OmScJ2nw3PUxW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rGdVujybocP36VY5' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/kelas_jabatan/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kelasJabatanController@delete',
        'controller' => 'App\\Http\\Controllers\\kelasJabatanController@delete',
        'namespace' => NULL,
        'prefix' => 'api/kelas_jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::rGdVujybocP36VY5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::y3QRTrFCRerR5tEM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kelas_jabatan/get-option-kelas-jabatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\kelasJabatanController@optionKelasJabatan',
        'controller' => 'App\\Http\\Controllers\\kelasJabatanController@optionKelasJabatan',
        'namespace' => NULL,
        'prefix' => 'api/kelas_jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::y3QRTrFCRerR5tEM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bGgkBYjmUjZHdBbj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/jabatan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jabatanController@list',
        'controller' => 'App\\Http\\Controllers\\jabatanController@list',
        'namespace' => NULL,
        'prefix' => 'api/jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::bGgkBYjmUjZHdBbj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AeWvQrHQ0HwgAmCB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/jabatan/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jabatanController@store',
        'controller' => 'App\\Http\\Controllers\\jabatanController@store',
        'namespace' => NULL,
        'prefix' => 'api/jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::AeWvQrHQ0HwgAmCB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Pt07QZh7PjUapDwA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/jabatan/show/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jabatanController@show',
        'controller' => 'App\\Http\\Controllers\\jabatanController@show',
        'namespace' => NULL,
        'prefix' => 'api/jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::Pt07QZh7PjUapDwA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YbBoQsvd4Lk3FPm5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/jabatan/update/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jabatanController@update',
        'controller' => 'App\\Http\\Controllers\\jabatanController@update',
        'namespace' => NULL,
        'prefix' => 'api/jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::YbBoQsvd4Lk3FPm5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::F1uSCMlw2rcQC4F7' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/jabatan/delete/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jabatanController@delete',
        'controller' => 'App\\Http\\Controllers\\jabatanController@delete',
        'namespace' => NULL,
        'prefix' => 'api/jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::F1uSCMlw2rcQC4F7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9CChuup5zPrvqOik' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/jabatan/get-option-jabatan-atasan/{params}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\jabatanController@jabatanAtasan',
        'controller' => 'App\\Http\\Controllers\\jabatanController@jabatanAtasan',
        'namespace' => NULL,
        'prefix' => 'api/jabatan',
        'where' => 
        array (
        ),
        'as' => 'generated::9CChuup5zPrvqOik',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
