<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return  $request->user();
// });
Route::post('/login', [App\Http\Controllers\AuthController::class, 'login']);
// Route::post('/logout', [App\Http\Controllers\AuthController::class, 'logout']);
Route::group(['middleware' => ['auth:sanctum']], function () {
    Route::post('/register-user', [App\Http\Controllers\AuthController::class, 'register_user']); 
    Route::post('/change-password', [App\Http\Controllers\AuthController::class, 'change_password']);  
    Route::post('/logout', [App\Http\Controllers\AuthController::class, 'logout']);
    Route::post('/face_id', [App\Http\Controllers\AuthController::class, 'face_id']);
    Route::get('/dashboard', [App\Http\Controllers\dashboardController::class, 'get_data']);
    Route::get('/current_user', [App\Http\Controllers\AuthController::class, 'current_user']);

    Route::prefix('satuan')->group(function () {
        Route::get('/list', [App\Http\Controllers\satuanController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\satuanController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\satuanController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\satuanController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\satuanController::class, 'delete']);  
    });

    Route::prefix('satuan_kerja')->group(function () {
        Route::get('/list', [App\Http\Controllers\satuanKerjaController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\satuanKerjaController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\satuanKerjaController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\satuanKerjaController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\satuanKerjaController::class, 'delete']);  
    });

    Route::prefix('pegawai')->group(function () {
        Route::get('/list', [App\Http\Controllers\pegawaiController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\pegawaiController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\pegawaiController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\pegawaiController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\pegawaiController::class, 'delete']);  
        Route::get('/get-option-agama', [App\Http\Controllers\pegawaiController::class, 'optionAgama']); 
        Route::get('/get-option-status-kawin', [App\Http\Controllers\pegawaiController::class, 'optionStatusKawin']);
        Route::get('/get-option-pendidikan-terakhir', [App\Http\Controllers\pegawaiController::class, 'pendidikanTerakhir']);  
        Route::get('/get-option-pangkat-golongan', [App\Http\Controllers\pegawaiController::class, 'optionGolongan']);  
        Route::get('/get-option-status-pegawai', [App\Http\Controllers\pegawaiController::class, 'optionStatusPegawai']);  
    });

    Route::prefix('jadwal')->group(function () {
        Route::get('/list', [App\Http\Controllers\jadwalController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\jadwalController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\jadwalController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\jadwalController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\jadwalController::class, 'delete']);  
    });

    Route::prefix('profil_daerah')->group(function () {
        Route::get('/list', [App\Http\Controllers\profilDaerahController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\profilDaerahController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\profilDaerahController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\profilDaerahController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\profilDaerahController::class, 'delete']);  
    });

    Route::prefix('informasi')->group(function () {
        Route::get('/list', [App\Http\Controllers\informasiController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\informasiController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\informasiController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\informasiController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\informasiController::class, 'delete']);  
    });

    Route::prefix('bidang')->group(function () {
        Route::get('/list', [App\Http\Controllers\bidangController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\bidangController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\bidangController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\bidangController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\bidangController::class, 'delete']);  
    });

    Route::prefix('kegiatan')->group(function () {
        Route::get('/list', [App\Http\Controllers\kegiatanController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\kegiatanController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\kegiatanController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\kegiatanController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\kegiatanController::class, 'delete']);  
    });

    Route::prefix('skp')->group(function () {
        Route::get('/list', [App\Http\Controllers\skpController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\skpController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\skpController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\skpController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\skpController::class, 'delete']);  
        Route::get('/get-option-satuan', [App\Http\Controllers\skpController::class, 'satuan']);  
        Route::get('/get-option-sasaran-kinerja', [App\Http\Controllers\skpController::class, 'optionSkp']);  
    });

    Route::prefix('aktivitas')->group(function () {
        Route::get('/list', [App\Http\Controllers\aktivitasController::class, 'list']); 
        Route::get('/list-by-user', [App\Http\Controllers\aktivitasController::class, 'listByUser']);  
        Route::post('/store', [App\Http\Controllers\aktivitasController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\aktivitasController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\aktivitasController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\aktivitasController::class, 'delete']);
        Route::get('/get-option-sasaran-kinerja', [App\Http\Controllers\aktivitasController::class, 'optionSkp']);
    });

    Route::prefix('realisasi_skp')->group(function () {
        Route::get('/list', [App\Http\Controllers\realisasiController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\realisasiController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\realisasiController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\realisasiController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\realisasiController::class, 'delete']);  
    });

    Route::prefix('atasan')->group(function () {
        Route::get('/list', [App\Http\Controllers\atasanController::class, 'list']);  
        Route::post('/store', [App\Http\Controllers\atasanController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\atasanController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\atasanController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\atasanController::class, 'delete']);  
    });

    Route::prefix('absen')->group(function () {
        Route::get('/list', [App\Http\Controllers\absenController::class, 'list']);
        Route::get('/get-time-now', [App\Http\Controllers\absenController::class, 'getTime']);  
        Route::post('/store', [App\Http\Controllers\absenController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\absenController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\absenController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\absenController::class, 'delete']);  
        Route::get('/check-absen', [App\Http\Controllers\absenController::class, 'checkAbsen']);  
    });

    Route::prefix('review_skp')->group(function () {
        Route::get('/list', [App\Http\Controllers\reviewController::class, 'list']);    
        Route::post('/store', [App\Http\Controllers\reviewController::class, 'store']);    
    });

    Route::prefix('review_realisasi')->group(function () {
        Route::get('/list', [App\Http\Controllers\reviewRealisasiSkpController::class, 'list']);    
        Route::post('/store', [App\Http\Controllers\reviewRealisasiSkpController::class, 'store']);    
    });

    Route::prefix('perilaku')->group(function () {
        Route::get('/list', [App\Http\Controllers\perilakuController::class, 'list']);    
        Route::post('/store', [App\Http\Controllers\perilakuController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\perilakuController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\perilakuController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\perilakuController::class, 'delete']);   
    });

    Route::prefix('faq')->group(function () {
        Route::get('/list', [App\Http\Controllers\faqController::class, 'list']);    
        Route::post('/store', [App\Http\Controllers\faqController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\faqController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\faqController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\faqController::class, 'delete']);   
    });

    Route::prefix('kelas_jabatan')->group(function () {
        Route::get('/list', [App\Http\Controllers\kelasJabatanController::class, 'list']);    
        Route::post('/store', [App\Http\Controllers\kelasJabatanController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\kelasJabatanController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\kelasJabatanController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\kelasJabatanController::class, 'delete']);   
        Route::get('/get-option-kelas-jabatan', [App\Http\Controllers\kelasJabatanController::class, 'optionKelasJabatan']);
    });

    Route::prefix('jabatan')->group(function () {
        Route::get('/list', [App\Http\Controllers\jabatanController::class, 'list']);    
        Route::post('/store', [App\Http\Controllers\jabatanController::class, 'store']);  
        Route::get('/show/{params}', [App\Http\Controllers\jabatanController::class, 'show']);  
        Route::post('/update/{params}', [App\Http\Controllers\jabatanController::class, 'update']);  
        Route::delete('/delete/{params}', [App\Http\Controllers\jabatanController::class, 'delete']);
        Route::get('/get-option-jabatan-atasan/{params}', [App\Http\Controllers\jabatanController::class, 'jabatanAtasan']);     
    });

});




